$(document).ready(function(){
	//Globals
	var config = {
		time: 80,
		speed: 1,
		intervalSpeed: 10
	}
	var gamePaused = false;
	var gameMover = null;
	var addNum = true;
	var numCounter = 0;
	var currentNumObj = null;
	var _speed = config.speed;
	var score = 0;	

	var shuffle = function (a) {
	    var j, x, i;
	    for (i = a.length; i; i -= 1) {
	        j = Math.floor(Math.random() * i);
	        x = a[i - 1];
	        a[i - 1] = a[j];
	        a[j] = x;
	    }
	    return a;
	}

	var _nums = [
		["n1",1,120,'$$\\frac{2}{3}$$'],
		["n2",1,150,'$$1$$'],
		["n3",1,120,'$$22\\frac{5}{9}$$'],
		["n4",1,120,'$$-13\\frac{10000}{300000}$$'],
		["n5",1,150,'$$1020$$'],
		["n6",1,120,'$$\\frac{0}{-1}$$'],
		["n7",1,120,'$$14\\frac{14}{14}$$'],
		["n8",1,150,'$$-4$$'],
		["n9",1,120,'$$\\frac{-21}{17}$$'],
		["n10",1,120,'$$\\sqrt{\\sqrt{81}}$$'],
		["n11",1,120,'$$\\frac{17}{53}$$'],
		["n12",1,150,'$$0$$'],
		["n13",1,120,'$$\\frac{77}{-71}$$'],
		["n14",1,120,'$$\\sqrt[3]{27}$$'],
		["n15",1,120,'$$\\frac{\\sqrt 9}{\\sqrt{25}}$$'],
		["n16",1,120,'$$-\\sqrt{16}$$'],
		["n17",1,120,'$$\\frac{\\sqrt 0}{3}$$'],
		["n18",1,120,'$$-100000$$'],
		["n19",1,120,'$$\\sqrt[4]{81}$$'],
		["n20",1,150,'$$-3.5$$'],
		["n21",1,130,'$$-\\sqrt 0$$'],
		["n22",1,120,'$$\\frac{0.98}{1.7}$$'],
		["n23",1,150,'$$10%$$'],
		["n24",1,120,'$$-0.0007$$'],
		["n25",1,120,'$$\\frac{15}{0.05}$$'],
		["n26",1,120,'$$\\frac{-\\sqrt 9}{0.013}$$'],
		["n27",1,120,'$$\\frac{27\\sqrt{81}}{0.05}$$'],
		["n28",0,120,'$$\\frac{15}{0.05}$$'],
		["n29",0,120,'$$-\\sqrt{1000}$$'],
		["n30",0,120,'$$\\sqrt{\\frac{2}{3}}$$'],
		["n31",0,150,'$$\\pi$$'],
		["n32",0,120,'$$\\sqrt[4]{27}$$'],
		["n33",0,120,'$$\\sqrt{101}$$'],
		["n34",0,120,'$$-\\sqrt{\\sqrt 3}$$'],
		["n35",0,120,'العدد النيبيري'],
		["n36",0,150,'$$ط$$'],
		["n37",0,130,'$$\\sqrt{171}$$'],
		["n38",0,130,'$$\\sqrt[5]{3}$$'],
		["n39",0,130,'$$-\\sqrt[3]{5}$$'],
		["n40",0,130,'$$\\frac{1}{0}$$']
	];

	

	var maxScore = _nums.length;


	var _currentSound = null;
	var counter = null;

	MathJax.Hub.Config({
	  tex2jax: {inlineMath: [['$','$'], ['\\(','\\)']]}	  
	});


		
	buildCounter();
	var startGame = function(){
		$( ".startScreen" ).show();
		$( ".startScreen" ).css("left",0);
		$( ".startScreen" ).css("top",0);
		$( ".endScreen" ).hide();
		_speed = config.speed;
		gamePaused = false;
		gameMover = null;
		addNum = true;
		numCounter = 0;
		currentNumObj = null;
		score = 0;
		counter.resetart();		
		_nums = shuffle(_nums);	
		if($( ".startScreen" ).height() < $( ".startScreen" ).width()){		
			$( ".startScreen" ).animate({
			  top:-$(this).height()
			}, 1000, "linear", function() {
			  $( ".startScreen" ).remove();
			  counter.start();
			});
		}else{
			$( ".startScreen" ).animate({
			  left:-$(this).width()
			}, 500, "linear", function() {
			  $( ".startScreen" ).remove();
			  counter.start();
			});
		}

		gameMover = setInterval(gameRun, config.intervalSpeed);
		//$(".maxscore").html(maxScore);
				
		// Drop Target
		$( ".dropTarget" ).droppable({
	      drop: function( event, ui ) {	      	
	        if((ui.draggable.attr("type") == 1 && $(this).attr("id") == "real") || (ui.draggable.attr("type") == 0 && $(this).attr("id") == "notreal")){
	        	score++;
	        }
	        ui.draggable.remove();
	        addNum = true;
	        $(this).removeClass("dt-over");
	        playSound("sounds/drop.mp3");
	      },
	      over: function( event, ui ) {
	      	$(this).addClass("dt-over");
	      },
	      out: function( event, ui ) {
	      	$(this).removeClass("dt-over");
	      }
	    });
	}
	$(document).on("mousedown",".dragNum",function(){
		playSound("sounds/drag.mp3");
	})
	var gameRun = function(){
		
		if(addNum){
			numCounter++;
			if(numCounter % 10 == 0){
				_speed+=0.5;
			}
			if(numCounter == (_nums.length+1)){
				endGame();
				return;
			}
			console.log("go", numCounter);
			$('.playArea').append('<div class="dragNum" type="'+_nums[numCounter-1][1]+'" id="n'+numCounter+'">'+_nums[numCounter-1][3]+'</div>');
			$( "#n"+numCounter ).draggable({
				start: function(event, ui) {
					$(this).css("z-index", 1000);
					$(this).addClass("onDrag");					
				},
				stop: function(event, ui) {
					$(this).removeClass("onDrag");
				},
				containment: $(".playArea")
			});
			$( "#n"+numCounter ).css("left", -150);	
			var _randomY = Math.round(Math.random() * ($(".playArea").height() - $( "#n"+numCounter ).height() - 100));
			$( "#n"+numCounter ).css("top", _randomY);	
			MathJax.Hub.Queue(["Typeset", MathJax.Hub, "'n"+numCounter+"'"]);
			MathJax.Hub.Queue(function(){
				$("#n" + numCounter + " .mjx-chtml").css("font-size",_nums[numCounter-1][2] + "%");
			}); 
			currentNumObj = $( "#n" + numCounter );

			$(".myscore").html(score);
			addNum = false;
			
		}

		var position = currentNumObj.position();

		if(position.left > ($('.playArea').width()+150)){
			currentNumObj.remove();
			currentNumObj  = null;
			addNum = true;
		}else{
			currentNumObj.css("left", (position.left + _speed));
		}
		

	}

	var buildItem = function(id){

	}

	var moveItem = function(id){
		
	}

	var pauseGame = function(){
		if(gamePaused){
			gameMover = setInterval(gameRun, config.intervalSpeed);
			gamePaused = false;
			$(".pauseScreen").hide();
		}else{
			$(".pauseScreen").show();
			clearInterval(gameMover); 
			gamePaused = true;
		}
		counter.pause();
	}

	var endGame = function(){
		if(currentNumObj){
			currentNumObj.remove();
			currentNumObj  = null;
		}
		clearInterval(gameMover);
		counter.stop();
		$(".endScreen #result").html(score +" / "+ maxScore);
		$(".endScreen").show();
	}

	// Sound Manager Setup
	
	soundManager.setup({

		    // where to find the SWF files, if needed
		    url: '/SoundManager2/swf/',
		    debugMode: false,
		    onready: function() {
		      
		    },

		    ontimeout: function() {
		      alert("Uh-oh. No HTML5 support, SWF missing, Flash blocked or other issue");
		    }

	});

	// Play Sound Function
	var playSound = function(s){
		_currentSound = soundManager.createSound({
			url: s
		});
		_currentSound.play();
	}

	// Counter Setup
	function buildCounter(){
		$(".stage").append('<div id="counter" class="counter"></div>');
		counter = $("#counter").countdown360({
		  radius      : 25,
		  seconds     : config.time,
		  strokeWidth : 5,
		  fillStyle   : '#dddddd',
		  strokeStyle : '#1ca3a6',
		  fontSize    : 16,
		  fontColor   : '#e10043',
		  autostart: false,
		  label: "",
		  onComplete  : function () { endGame(); }
		});
	}

	
	$(".pause, .continue").on("click",function(){
		pauseGame();
	});

	$(".endgame").on("click",function(){
		startGame();
	});

	$(document).on("click", "#startBtn",function(){
		startGame();
		return false;
	});

	$( window ).resize(function() {
		var _randomY = Math.round(Math.random() * ($(".playArea").height() - currentNumObj.height() - 100));
		currentNumObj.css("top", _randomY);	
	});


// Clock (Extra)
	function updateTime() {
	    var dateInfo = new Date();

	    /* time */
	    var hr,
	    _min = (dateInfo.getMinutes() < 10) ? "0" + dateInfo.getMinutes() : dateInfo.getMinutes(),
	        sec = (dateInfo.getSeconds() < 10) ? "0" + dateInfo.getSeconds() : dateInfo.getSeconds(),
	        ampm = (dateInfo.getHours() >= 12) ? "مساءاً" : "صباحاً";

	    // replace 0 with 12 at midnight, subtract 12 from hour if 13–23
	    if (dateInfo.getHours() == 0) {
	        hr = 12;
	    } else if (dateInfo.getHours() > 12) {
	        hr = dateInfo.getHours() - 12;
	    } else {
	        hr = dateInfo.getHours();
	    }

	    var currentTime = hr + ":" + _min + ":" + sec;

	    // print time
	    document.getElementsByClassName("hms")[0].innerHTML = currentTime;
	    document.getElementsByClassName("ampm")[0].innerHTML = ampm;

	    /* date */
	    var dow = [
	        "الاحد",
	        "الاثنين",
	        "الثلاثاء",
	        "الأربعاء",
	        "الخميس",
	        "الجمعة",
	        "السبت"
	    ],
	        month = [
	            "1",
	            "2",
	            "3",
	            "4",
	            "5",
	            "6",
	            "7",
	            "8",
	            "9",
	            "10",
	            "11",
	            "12"
	        ],
	        day = dateInfo.getDate();

	    // store date
	    var currentDate = "<span class='day'>" + dow[dateInfo.getDay()] + "</span>، " + month[dateInfo.getMonth()] + " " + day;

	    document.getElementsByClassName("date")[0].innerHTML = currentDate;
	};

	// print time and date once, then update them every second
	updateTime();
	setInterval(function () {
	    updateTime()
	}, 1000);
	// End Clock
});